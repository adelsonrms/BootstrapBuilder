﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BootstrapBuilder.Components
{
    public  class BSElementBase
    {
        public string Title { get; set; }
        protected string ClassBase { get; set; }
    }
}
