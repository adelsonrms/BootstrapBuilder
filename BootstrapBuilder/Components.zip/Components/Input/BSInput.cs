﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text;

namespace BootstrapBuilder.Components
{
    public class BSInput
    {
        #region Propriedades

        private string _bsClass = "form-control";
        private string _id;

        public string Name { get; set; }
        public string Type { get; set; }
        public string Mask { get; set; }
        public string Tooltip { get; set; }
        public string PlaceHolder { get; set; }
        public string BSClass { get { return _bsClass; } set { _bsClass = value; } }
        public bool ReadOnly { get; set; }
        public bool Requeried { get; set; }
        public bool Enabled { get; set; }
        public string Label { get; set; }
        public string Value { get; set; }
        public string MaxLenght { get; set; }

        public string[] Columns { get; set; }

        public string Id
        {
            get
            {
                if (_id == null) { _id = Guid.NewGuid().ToString().Substring(1, 6); }

                return _id;
            }
            set
            { _id = value; }

        }
        #endregion

        #region Construtores
        /// <summary>
        /// -------------------------------------------------------------------------------------
        /// Autor   : Adelson RM Silva, 26/01/2018
        /// -------------------------------------------------------------------------------------
        /// Inicializa um novo Panel ja informando o titulo
        /// </summary>
        /// <remarks>O titulo informado será usando para gerar automaticamente o ID do painel e tambem o ID da Div que será o corpo do conteudo</remarks>
        /// <param name="title"></param>
        public BSInput(string type)
        {
            initializeDefault(type, null);
        }

        public BSInput(string type, string id)
        {
            initializeDefault(type, id);
        }

        public BSInput()
        {
            initializeDefault("text", null);
        }

        void initializeDefault(string type, string id)
        {
            Type = type;
            if (id!=null) {Id = TrataCaracteres(id);}

            Columns = new string[2];

            Columns[0] = "2";
            Columns[1] = "4";
        }

        #endregion
        /// <summary>
        /// -------------------------------------------------------------------------------------
        /// Autor   : Adelson RM Silva, 26/01/2018
        /// -------------------------------------------------------------------------------------
        /// Faz o tratamento de alguns caracteres especiais que não podem aparecer em IDs
        /// </summary>
        private string TrataCaracteres(string text)
        {
            return text.Replace(" ", "_").Replace("/", "_").Replace("\\", "_").Replace("%", "_").Replace("&", "_");
        }
        #region Métodos publicos
        /// <summary>
        /// -------------------------------------------------------------------------------------
        /// Autor   : Adelson RM Silva, 26/01/2018
        /// -------------------------------------------------------------------------------------
        /// Recupera o HTML que representa o cabeçalho
        /// </summary>
        public string GetHTML()
        {

            var html = new StringBuilder();
            html.AppendFormat("<div id='{0}' class='row sp-vertical'>", "Row_" + TrataCaracteres(Id)).AppendLine();

            html.AppendFormat("  <div class='col-sm-{0}'>", Columns[0]).AppendLine();
            html.AppendFormat("       <label class='control-label' for='{0}'>{1}</label>", TrataCaracteres(Id), Label).AppendLine();
            html.AppendFormat("  </div>").AppendLine();

            html.AppendFormat("  <div class='col-sm-{0}'>", Columns[1]).AppendLine();
            html.AppendFormat("     <input name='{0}' class='{1}' id='{0}' type='{2}' placeholder='{3}' {4} {5}></input>", TrataCaracteres(Id), _bsClass, Type, PlaceHolder == null ? Tooltip==null?Label:Tooltip : PlaceHolder, new BSTooltip(Tooltip, Label).Html(), extendedAttributes());
            html.AppendFormat("  </div>").AppendLine();

            html.AppendFormat("   </div>").AppendLine();
            return html.ToString();
        }

        private string extendedAttributes()
        {
            var att = new StringBuilder();
            if (MaxLenght != null) { att.AppendFormat("maxlenght = '{0}'", MaxLenght).AppendLine(); }
            att.AppendFormat(ReadOnly == true ? " readonly'" : "").AppendLine();
            att.AppendFormat(Enabled == false ? " desabled'" : "").AppendLine(); 
            att.AppendFormat(Requeried == true ? " required'" : "").AppendLine();
            return att.ToString();
        }


        #endregion
    }

}
    
